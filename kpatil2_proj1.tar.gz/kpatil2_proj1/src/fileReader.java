import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.jsoup.Jsoup;


public class fileReader {

	public static String inputFileArray[] ;
	public static String outputFileArray[] ;
//public static ArrayList<ArrayList<String>> globalDocTokenTracker = new ArrayList<ArrayList<String>>();
public static Map<String,ArrayList<String>> globalDocTokenTracker = new HashMap<String,ArrayList<String>>();
	
	
	public static void main(String[] args) {
		ArrayList<String> finalDataArray = new ArrayList<String>();
				int argsLength = args.length;
			//	System.out.println(args.length);
		if(argsLength%2==0)
		{
		
			inputFileArray = new String[argsLength/2];
			outputFileArray = new String[argsLength/2];
			for(int i=0;i<argsLength/2;i++)
			{
			//	System.out.println("Input files -"+args[i]);
				inputFileArray[i] = args[i];
			}
			//System.out.println(argsLength/2+"\t"+(argsLength+1));
			
			for(int j=0;j<argsLength/2;j++)
			{
			//	System.out.println(j);
			//	System.out.println("Output files -"+args[(argsLength/2+j)]);
				outputFileArray[j] = args[(argsLength/2+j)];
			}
			
		}
		else
		{
			System.out.println("incorrect number of input and output files given");
			inputFileArray = new String[0];
			outputFileArray = new String[0];
			
		}
		
			
		//}
		//File file = new File("InputFolder");
	//	File [] files = file.listFiles();
		for(int z=0;z<inputFileArray.length;z++)
		
		{
			
			//System.out.println("i is---"+fileInputCount+"\t "+args[fileInputCount]);
			
			
			
			
		
		org.jsoup.nodes.Document doc;
		
		try {
			doc = Jsoup.parse(new File(inputFileArray[z]),"UTF-8");
		
		String extractedData = doc.body().text();
		extractedData.replaceAll("\\s+", " ");
		String[] dataArray = extractedData.split("\\s+");
		
		//System.out.println("Size of dataArray is---->"+dataArray.length);
		for(int i=0;i<dataArray.length;i++)
		{
			
			if(!dataArray[i].contains("."))
			{
			
				if((dataArray[i].contains("-")))
				{
					dataArray[i] = dataArray[i].toLowerCase().trim().replaceAll("\\W", " ");
		//	System.out.println(dataArray[i]+"\t---Replaced as----\t"+dataArray[i].toLowerCase().trim().replaceAll("-", " "));
				}
				else if((dataArray[i].contains("/")))
				{
					dataArray[i] = dataArray[i].toLowerCase().trim().replaceAll("/"," ");
				}
				
				else
				{
					
					dataArray[i] = dataArray[i].toLowerCase().trim().replaceAll("\\W", " ");
				//	System.out.println(dataArray[i]+"\t---Replaced as----\t"+dataArray[i].toLowerCase().trim().replaceAll("\\W", ""));
				}
								
			}
			else
			{
				
			
				char[] dataArr = dataArray[i].toCharArray();
			//	System.out.println("for "+dataArray[i]+" charArray is"+ Arrays.toString(dataArr));
				int dotCounter =0 ;
				int charcounter=0;
				for(int m=0;m<dataArr.length;m++)
				{
					//System.out.println("--"+dataArr[m]);
					
					if(dataArr[m]=='.')
					{
						dotCounter = dotCounter + 1;
					}
					else
					{
						charcounter = charcounter + 1;
					}
					
					
				}
			//	System.out.println("C"+charcounter);
			//	System.out.println("D"+dotCounter);
			//	System.out.println(dataArray[i]);
				if(dotCounter == charcounter)
				{
				//	System.out.println("Possible Abbrivation");
					//if(!dataArray[i].matches("[\\w.]"))
			//	System.out.println(dataArray[i]);
			//		System.out.println("CON1");
					dataArray[i] = dataArray[i].toLowerCase().trim();
					
				}
				else if(charcounter / dotCounter == 1 )
				{
			//		System.out.println("Possible Abbrivation-1");
			//		System.out.println(dataArray[i].replaceAll("\\W$", ""));
				//	System.out.println("CON2");
					if(dataArray[i].contains("3.7"))
					{
						dataArray[i] = dataArray[i].trim().replaceAll("^\\D", "").replaceAll("\\W$", "");
					}
					else
					{
					dataArray[i] = dataArray[i].toLowerCase().trim().replaceAll("\\W$", "");
					}
				}
				else
				{
					
					
					if(dataArray[i].charAt(dataArray[i].length()-1)=='.' && dotCounter==1)
					{	
					//System.out.println("Its fullstop");
					//System.out.println(dataArray[i].replaceAll("\\W",""));
						//dataArray[i] = dataArray[i].replaceAll("\\W","");
					
						dataArray[i]=dataArray[i].toLowerCase().trim().replaceAll("\\W"," ");
					}
					else if(dataArray[i].charAt(dataArray[i].length()-1)=='.' && dotCounter>1)
					{
						//System.out.println(". is in between");
				
						//System.out.println(dataArray[i]);
				//		System.out.println(dataArray[i]);
						dataArray[i] = dataArray[i].toLowerCase().trim().replaceAll("\\W$*", " ");
						//System.out.println(dataArray[i]);
					}
					else if(dataArray[i].charAt(dataArray[i].length()-1)!='.' && dotCounter > 1)
					{
						//System.out.println(". is in between");
				
						//System.out.println(dataArray[i]);
						/*if(dataArray[i].contains("ucbvax"))
						{
							System.out.println(dataArray[i].replaceAll("\\W", " "));
						}*/
						//System.out.println(dataArray[i].replaceAll("^\\W*", ""));
						/*if(dataArray[i].equals("2.10"))
						{
							System.out.println("YES-1");
						}*/
						
						if(dataArray[i].contains("@"))
						{
							dataArray[i] = dataArray[i].toLowerCase().trim();
						}
						else
						{
					//		System.out.println(dataArray[i]);
						dataArray[i] = dataArray[i].toLowerCase().trim().replaceAll("\\W", " ");
					//	System.out.println(dataArray[i]);
						}
						}
					else
					{
						
					//	System.out.println(dataArray[i]);
				//	System.out.println(dataArray[i]);
						
						if(dataArray[i].matches("-?\\d+(\\.\\d+)?"))
						{
							dataArray[i] = dataArray[i].trim().replaceAll("^\\D", "");
						//	System.out.println("YES-2");
							//System.out.println(dataArray[i]);
						}
						else
						{
						dataArray[i] = dataArray[i].toLowerCase().trim().replaceAll("\\W", " ");
						}
					//	System.out.println(dataArray[i]);
					}
				}
		
		}	}
		
		for(int k=0;k<dataArray.length;k++)
		{
			if(!dataArray[k].contains("."))
			{
				finalDataArray.add(k, dataArray[k].toLowerCase().trim().replaceAll("\\W", " "));
			}
			else
			{
				
				finalDataArray.add(k, dataArray[k].trim());
			}	
			
		}
		
		for(int a=0;a<finalDataArray.size();a++)
		{
			if(finalDataArray.get(a).split("\\s+").length>1)
			{

				finalDataArray.add(a+1,finalDataArray.get(a).split("\\s+")[0]);
				finalDataArray.add(a+2,finalDataArray.get(a).split("\\s+")[1]);
				finalDataArray.remove(a);
			}
			
		}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("No Such file exists\nEnter correct file name");
			System.exit(0);
		}
		Collections.sort(finalDataArray);
		ArrayList<String> tempFinalDataArray = new ArrayList<String>();
		
		for(int k=0;k<finalDataArray.size();k++)
		{
			if(finalDataArray.get(k).length()!=0)
			{	tempFinalDataArray.add(finalDataArray.get(k));
			}
		}
		//System.out.println("**"+outputFileArray[z]);
		//System.out.println(tempFinalDataArray);
		Set<String> testSet = new TreeSet<String>();
		for(int i=0;i<tempFinalDataArray.size();i++)
		{
			testSet.add(tempFinalDataArray.get(i));
			
		}
		ArrayList<String> tempFinalDataArray1 = new ArrayList<String>();
		Iterator<String> itr = testSet.iterator();
		
		while (itr.hasNext())
		{
			tempFinalDataArray1.add(itr.next());
		}
		//Collections.sort(testSet);
		//System.out.println(testSet.size());
		//System.out.println(testSet);
		
		globalDocTokenTracker.put(outputFileArray[z], tempFinalDataArray1);
		//tempFinalDataArray.clear();
		finalDataArray.clear();
	 

		}
		
	//	System.out.println(globalDocTokenTracker.values());
		
		Set<String> tempSet = new HashSet<String>();
		tempSet = globalDocTokenTracker.keySet();
		for (String s : tempSet)
		{
			//wrtie set iterator
			//	System.out.println(s);
			File outFile= new File(s);
			try {
		//		System.out.println("Writing to "+outFile);
				FileWriter writeFile = new FileWriter(outFile);
		
				for(int k=0;k<globalDocTokenTracker.get(s).size();k++)
				{
					//System.out.println(globalDocTokenTracker.get(s).get(k));
					writeFile.write(globalDocTokenTracker.get(s).get(k)+"\n");
				}
				writeFile.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Unable to write output file..Please check permissions");
				System.exit(0);
			}
			
		}
		System.out.println("Output files generated");
		
	}

}
