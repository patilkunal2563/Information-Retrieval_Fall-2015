Programming Language used --- Java
Run Program with command like "./Submission 0002.html 0018.html 0036.html 02.txt 18.txt 36.txt"
Program checks if number of input files and number of output files are same. It can generate output file
of any name.

Program reads .html file and then creates tokens in lexicographic order. Program removes
duplicate tokens.
Output files are generated in source folder only with .txt extension.
