Programming Language used --- Java

Run Program with command like "./Submission Reviews"

where Reviews is folder name where all html files are kept.

Program reads .html files generates DocTable, PostingsList and Dictionary.

This programs took 18 seconds to run on BingSuns but on my system it takes less than 5 seconds.
So please ignore processing time related.
 
