import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.TreeSet;
import org.jsoup.Jsoup;


public class fileReader {

	public static String inputFileArray[];
	public static String outputFileArray[];
	public static Map<String, ArrayList<String>> globalDocTokenTracker = new HashMap<String, ArrayList<String>>();
	public static Map<String, String> docTable = new TreeMap<String, String>();
	public static Map<String, Integer> termFrequencyTable = new HashMap<String, Integer>();
	public static Map<String, Integer> tempTermFrequencyTable = new HashMap<String, Integer>();
	public static Map<String, Map<String, Integer>> finalTermFrequencyTable = new HashMap<String, Map<String, Integer>>();
	public static int globalOffsetCounter = 0;

	public static void main(String[] args) {
		
		ArrayList<String> finalDataArray = new ArrayList<String>();
	
		String directoryPath = args[0];

		File file = new File(directoryPath);
		File[] files = file.listFiles();

		for (int z = 0; z < files.length; z++)

		{
			org.jsoup.nodes.Document doc;

			try {

				doc = Jsoup.parse(files[z], "UTF-8");
				String e = doc.title();
				String extractedData = doc.body().text();
				if(extractedData.isEmpty())
				{
					System.out.println("File with empty body tag detected..Exiting "+files[z].getName());
					System.exit(0);
				}
				extractedData.replaceAll("\\s+", " ");
				String[] dataArray = extractedData.split("\\s+");
				docTable.put(files[z].getName().substring(0, 4), e);
				for (int i = 0; i < dataArray.length; i++) {

					if (!dataArray[i].contains(".")) {

						if (dataArray[i].matches("[0-9]+[+%']"))

						{
							// System.out.println(dataArray[i]);
							dataArray[i] = dataArray[i].toLowerCase().trim();
						} else if (dataArray[i].matches("[0-9]+,[0-9]+"))

						{
							// System.out.println(dataArray[i]);
							dataArray[i] = dataArray[i].toLowerCase().trim();
						} else if (dataArray[i].matches("\\W\\d")) {
							// System.out.println(dataArray[i]);
							dataArray[i] = dataArray[i].toLowerCase().trim();
						} else if (dataArray[i].matches("\\d")) {
							// System.out.println(dataArray[i]);
							dataArray[i] = dataArray[i].toLowerCase().trim();
						} else if (dataArray[i].matches("[0-9]+[)]")) {

							dataArray[i] = dataArray[i].toLowerCase().trim()
									.replaceAll("\\W$", "");

						} else if (dataArray[i].matches("[(][0-9]+")) {
							//System.out.println(dataArray[i]);
							dataArray[i] = dataArray[i].toLowerCase().trim()
									.replaceAll("\\^W", "");
							//System.out.println(dataArray[i]);
						} else if ((dataArray[i].contains("-"))) {

							dataArray[i] = dataArray[i].toLowerCase().trim()
									.replaceAll("\\W", " ");
							// System.out.println(dataArray[i]+"\t---Replaced as----\t"+dataArray[i].toLowerCase().trim().replaceAll("-",
							// " "));
						} else if ((dataArray[i].contains("/"))) {
							dataArray[i] = dataArray[i].toLowerCase().trim()
									.replaceAll("/", " ");
						}

						else {

							dataArray[i] = dataArray[i].toLowerCase().trim()
									.replaceAll("\\W", " ");
							// System.out.println(dataArray[i]+"\t---Replaced as----\t"+dataArray[i].toLowerCase().trim().replaceAll("\\W",
							// ""));
						}

					} else

					{
						if (dataArray[i].matches("\\W\\d")) {
							dataArray[i] = dataArray[i].toLowerCase().trim();
						} else if (dataArray[i].matches("\\W[0-9.]+[0-9]")) {
							dataArray[i] = dataArray[i].toLowerCase().trim();
						} else if (dataArray[i].matches("\\W[0-9.]+[0-9]\\W")) {
							// System.out.println(dataArray[i]);
							dataArray[i] = dataArray[i].toLowerCase().trim()
									.replaceAll("\\W$", "");
							// System.out.println(dataArray[i]);
						}
						/*
						 * else if(dataArray[i].matches("\\W\\d")) {
						 * System.out.println(dataArray[i]); }
						 */

						else if (dataArray[i].matches("(([a-z])(?:\\.?)){2,}")) {

							dataArray[i] = dataArray[i].toLowerCase().trim()
									.replaceAll("\\W", " ");

						}

						else {
							char[] dataArr = dataArray[i].toCharArray();
							int dotCounter = 0;
							int charcounter = 0;
							for (int m = 0; m < dataArr.length; m++) {
								if (dataArr[m] == '.') {

									dotCounter = dotCounter + 1;
								} else {
									charcounter = charcounter + 1;
								}

							}
							if (dotCounter == charcounter) {
							dataArray[i] = dataArray[i].toLowerCase().trim();
							} else if (charcounter / dotCounter == 1) {
								dataArray[i] = dataArray[i].toLowerCase().trim().replaceAll("\\W", "");
							} 
						}
					}
				}

				for (int k = 0; k < dataArray.length; k++) {

					if (!dataArray[k].contains(".")) {
						if (dataArray[k].matches("[0-9]+[+%']"))

						{

							// System.out.println(dataArray[i]);
							dataArray[k] = dataArray[k].toLowerCase().trim();
						} else if (dataArray[k].matches("[0-9]+,[0-9]+"))

						{
							// System.out.println(dataArray[i]);
							dataArray[k] = dataArray[k].toLowerCase().trim();
						} else if (dataArray[k].matches("\\W\\d")) {
							// System.out.println(dataArray[i]);
							dataArray[k] = dataArray[k].toLowerCase().trim();
						} else if (dataArray[k].matches("\\d")) {
							// System.out.println(dataArray[i]);
							dataArray[k] = dataArray[k].toLowerCase().trim();
						}

						else {
							// System.out.println(dataArray[k]);
							dataArray[k] = dataArray[k].toLowerCase().trim()
									.replaceAll("\\W", " ");
						}
					} else if (dataArray[k].contains("@")) {

						dataArray[k] = dataArray[k].toLowerCase().trim()
								.replaceAll("^\\W", "").replaceAll("\\W$", "");
						// System.out.println(dataArray[k]);
					} else {

						if (dataArray[k].contains(".")) {
							if (dataArray[k].length() > 5
									&& !dataArray[k]
											.matches("\\W[0-9]+.[0-9]+")) {

								dataArray[k] = dataArray[k].toLowerCase()
										.trim().replaceAll("\\W", "");
							}

							else if (dataArray[k].matches("[0-9]+[.]")) {

								dataArray[k] = dataArray[k].toLowerCase()
										.trim().replaceAll("\\W", "");
							} else {
								// System.out.println(dataArray[k].toLowerCase().trim().replaceAll("[^a-zA-Z.]",
								// ""));
								if (dataArray[k].matches("\\W[0-9]+.[0-9]+")) {
									// System.out.println(dataArray[k]);
									dataArray[k] = dataArray[k].toLowerCase()
											.trim();
								} else if (dataArray[k].equals(".")) {
									// System.out.println(dataArray[k]);
									dataArray[k] = dataArray[k]
											.replace(".", "");
									// System.out.println(dataArray[k]);
								} else {

									dataArray[k] = dataArray[k].toLowerCase()
											.trim()
											.replaceAll("[^a-zA-Z.]", "");
									// System.out.println(dataArray[k]);
									if ((dataArray[k].contains("..."))
											|| (dataArray[k]
													.matches("[a-z]+[.]{2,}"))
											|| (dataArray[k].matches("^[.]") || (dataArray[k]
													.matches("^[.][a-z]+")))) {

										dataArray[k] = dataArray[k]
												.toLowerCase().trim()
												.replaceAll("\\W", "");
									} else if (dataArray[k]
											.matches("[a-z]{2,}\\W")) {
										dataArray[k] = dataArray[k]
												.toLowerCase().trim()
												.replaceAll("\\W", "");
									} else {
										dataArray[k] = dataArray[k]
												.toLowerCase().trim();
									}
								}

							}

						}

					}

				}
				for (int k = 0; k < dataArray.length; k++) {
					finalDataArray.add(k, dataArray[k]);

				}
				for (int a = 0; a < finalDataArray.size(); a++) {

					if (finalDataArray.get(a).split("\\s+").length > 1) {

						finalDataArray.add(a + 1,
								finalDataArray.get(a).split("\\s+")[0]);
						finalDataArray.add(a + 2,
								finalDataArray.get(a).split("\\s+")[1]);
						finalDataArray.remove(a);
					}

				}
				Collections.sort(finalDataArray);

				// / Generating TF HERE NOW
				// /

				ArrayList<String> tempFinalDataArray = new ArrayList<String>();

				for (int k = 0; k < finalDataArray.size(); k++) {
					if (finalDataArray.get(k).length() != 0) {
						tempFinalDataArray.add(finalDataArray.get(k));
					}
				}
				// System.out.println("**"+outputFileArray[z]);
				// System.out.println(tempFinalDataArray);
				Set<String> tempSet = new TreeSet<String>(tempFinalDataArray);
				//int counter = 0;
				for (String str : tempSet) {
					//counter++;
					termFrequencyTable.put(str +"_"+ files[z].getName().substring(0, 4),Collections.frequency(tempFinalDataArray, str));
				}
	
				Set<String> testSet = new TreeSet<String>();
				for (int i = 0; i < tempFinalDataArray.size(); i++) {

					testSet.add(tempFinalDataArray.get(i));

				}
				ArrayList<String> tempFinalDataArray1 = new ArrayList<String>();
				Iterator<String> itr = testSet.iterator();

				while (itr.hasNext()) {
					tempFinalDataArray1.add(itr.next());
				}
			
				globalDocTokenTracker.put(files[z].getName().substring(0, 4),
						tempFinalDataArray1);
				// tempFinalDataArray.clear();
				finalDataArray.clear();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		Map<String, Integer> finalTermFreq = new TreeMap<String, Integer>();

		Set<String> mySet = termFrequencyTable.keySet();

		for (String s : mySet) {
			
			finalTermFreq.put(s, termFrequencyTable.get(s));
			}

		File f1 = new File("DocsTable.txt");
		try {

			FileWriter writer1 = new FileWriter(f1);
			BufferedWriter wrt1 = new BufferedWriter(writer1);
			wrt1.write("Doc Number \t\t\t\t\t Title \t\n");
			Set<String> doctableSet = docTable.keySet();

			for (String string : doctableSet) {
				wrt1.write(string + "\t\t\t\t\t\t" + docTable.get(string) + "\n");
			}
			wrt1.close();
			writer1.close();
			System.out.println("DocsTable Generated");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		File f = new File("PostingList.txt");
		try {
			FileWriter writer = new FileWriter(f);
			BufferedWriter wrt2 = new BufferedWriter(writer);
			Set<String> mySet1 = finalTermFreq.keySet();
			wrt2.write("DocId \t   tf\t\n");
			for (String s : mySet1) {
				
				//System.out.println(s+"\t\t"+finalTermFreq.get(s));
				
				wrt2.write(s.split("_")[1] + "\t\t" + finalTermFreq.get(s)
						+ "\n");
			}
			System.out.println("PostingsList Generated");
			wrt2.close();
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//System.out.println(timeTillHere - timeFromHere);
		
		
		//long timeFromHere = System.currentTimeMillis();
		Set<String> tempSet = new HashSet<String>();
		tempSet = globalDocTokenTracker.keySet();
		
		StringBuffer finalDictionary = new StringBuffer();
		List<String> list = new ArrayList<String>();
		
		for (String s : tempSet) {
				for (int k = 0; k < globalDocTokenTracker.get(s).size(); k++) {
				finalDictionary = finalDictionary.append(globalDocTokenTracker.get(s).get(k) + "\n");

					}		
			}
		//long timeTillHere = System.currentTimeMillis();
	//	System.out.println(timeTillHere - timeFromHere);
		
		StringTokenizer token = new StringTokenizer(finalDictionary.toString());
		
		while(token.hasMoreTokens())
		{
			
		list.add(token.nextToken());
			//System.out.println(token.nextToken()+"\t\t"+ );
			
		}
		
		Collections.sort(list);
		
		Set<String> uniqueWords = new TreeSet<String>(list);
		Iterator<String> itr = uniqueWords.iterator();
		int offsetCounter = 0;
		File outfile = new File("Dictionary.txt");
		FileWriter writeFile;
		try {
			writeFile = new FileWriter(outfile);
			BufferedWriter wrt = new BufferedWriter(writeFile);
		//	long stime = System.currentTimeMillis();
			wrt.write("TERM\t\t\t\t\t\t DF \t\t\t\t\t\t Offset\n");
			while(itr.hasNext()) {
				
				StringBuffer word = new StringBuffer();
				word.append(itr.next());
				
				if (offsetCounter == 0 && word.toString().length() != 0) {
					
					wrt.write(word.toString()+"\t\t\t\t\t\t"+Collections.frequency(list, word.toString())+ "\t\t\t\t\t\t" + 0+ "\n") ;
					
					
				} else {
					if (word.toString().length() != 0) {
						wrt.write(word.toString()+"\t\t\t\t\t\t"+Collections.frequency(list, word.toString())+ "\t\t\t\t\t\t" + (offsetCounter)+ "\n") ;
						
					}

				}
				globalOffsetCounter = Collections.frequency(list, word.toString());
				offsetCounter += globalOffsetCounter;
			}
			wrt.close();
			writeFile.close();
			System.out.println("Dictionary Generated");
			//long ttime = System.currentTimeMillis();
			//System.out.println(ttime-stime);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
